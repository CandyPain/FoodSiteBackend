﻿using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.Others;

namespace FoodSite.Services
{
    public interface IUserService
    {
        Task<TokenResponse> RegisterAsync(UserRegisterModel userRegisterModel);
        Task<TokenResponse> LoginAsync(LoginCredentials LC);
        Task<UserDto> GetProfileAsync(Guid userId);
        Task<TokenResponse> EditProfileAsync(Guid userId, UserEditModel userEditModel);
        Task LogOutAsync(TokenBan token);
    }

}
