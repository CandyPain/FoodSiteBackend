﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using System.Security.Authentication;
using System.Security.Claims;

namespace FoodSite.Services
{
    public class BasketService : IBasketService
    {
        private readonly AppDbContext _context;
        public BasketService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<DishBasketDto>> GetBasketAsync(Guid userId)
        {
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            List<Order> userOrders = _context.Orders.Where(o => o.UserId == user.Id).ToList();
            Order? currentOrder = userOrders.FirstOrDefault(o => o.Status == OrderStatus.CurrentOrder);
            if (currentOrder == null)
            {
                return new List<DishBasketDto>();
            }
            var basket = _context.CartItems
                .Where(ci => ci.OrderId == currentOrder.Id)
                .Select(item => new DishBasketDto
                {
                    Id = item.Dish.Id,
                    Name = item.Dish.Name,
                    Price = item.Dish.Price,
                    TotalPrice = item.Dish.Price * item.Count,
                    Amount = item.Count,
                    Image = item.Dish.Image
                })
                .ToList();
            return basket;
        }

        public async Task AddDishAsync(Guid userId, Guid dishId, int Count)
        {
            bool IsNewOrder = false;
            Dish? CurrentDish = _context.Dishes.SingleOrDefault(d => d.Id == dishId);
            if (CurrentDish == null) { throw new NotFoundExeption("Dish not found"); }
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            List<Order> userOrders = _context.Orders.Where(o => o.UserId == user.Id).ToList();
            Order? CurrentOrder = userOrders.FirstOrDefault(o => o.Status == OrderStatus.CurrentOrder);
            if (CurrentOrder == null)
            {
                CurrentOrder = new Order();
                //CurrentOrder.CartItems = new List<CartItem>();
                CurrentOrder.Status = OrderStatus.CurrentOrder;
                CurrentOrder.UserId = user.Id;
                CurrentOrder.AddressId = user.AddressId;
                IsNewOrder = true;
            }
            CartItem? CheckInOrder = _context.CartItems.SingleOrDefault(ci => ci.OrderId == CurrentOrder.Id && ci.DishId == CurrentDish.Id);
            if (CheckInOrder != null)
            {
                CheckInOrder.Count += Count;
                CurrentOrder.Price += CurrentDish.Price * Count;
            }
            else
            {
                //CurrentOrder.CartItems.Add(newItem);
                CurrentOrder.Price += CurrentDish.Price * Count;
                CartItem newItem = new CartItem(dishId, CurrentOrder.Id, Count);
                _context.CartItems.Add(newItem);
                if (IsNewOrder) _context.Orders.Add(CurrentOrder);
            }
            _context.SaveChanges();
            return;
        }

        public async Task DeleteDishAsync(Guid userId, Guid dishId, bool decrease)
        {
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            List<Order> userOrders = _context.Orders.Where(o => o.UserId == user.Id).ToList();
            Order? CurrentOrder = userOrders.FirstOrDefault(o => o.Status == OrderStatus.CurrentOrder);
            if (CurrentOrder == null)
            {
                throw (new NotFoundExeption("Order is empty"));
            }
            Dish? CurrentDish = _context.Dishes.SingleOrDefault(d => d.Id == dishId);
            if(CurrentDish == null) { throw new NotFoundExeption("Dish does not found"); }
            CartItem? item = _context.CartItems.SingleOrDefault(ci => ci.OrderId == CurrentOrder.Id && ci.DishId == dishId);
            if (item == null)
            {
                throw (new NotFoundExeption("Dish not found"));
            }
            if (decrease)
            {
                item.Count -= 1;
                CurrentOrder.Price -= CurrentDish.Price;
            }
            else
            {
                _context.CartItems.Remove(item);
                CurrentOrder.Price -= CurrentDish.Price * item.Count;
            }
            _context.SaveChanges();

            return;
        }
        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }
    }
}
