﻿using FoodSite.Models;
using FoodSite.Services.ModelsForServices;
using Microsoft.EntityFrameworkCore;
using System.Security.Authentication;

namespace FoodSite.Services
{
    public interface IBannedTokensService
    {
        void CheckAuthentication(TokenBan token);
    }
}
