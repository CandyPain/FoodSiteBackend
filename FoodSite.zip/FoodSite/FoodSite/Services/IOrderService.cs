﻿using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;

namespace FoodSite.Services
{
    public interface IOrderService
    {
        Task<List<OrderInfoDto>> GetOrdersAsync(Guid userId);
        Task<OrderDto> GetOrderAsync(Guid id, Guid userId);
        Task<OrderCreateDto> CreateOrderAsync(Guid userId);
        Task<OrderStatus> PostOrderStatusAsync(Guid id);
    }
}
