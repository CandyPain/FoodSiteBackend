﻿using FoodSite.Data;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.Others;
using FoodSite.Services.ModelsForServices;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System.Text.RegularExpressions;

namespace FoodSite.Services
{
    public class UserService : IUserService
    {
        private readonly AppDbContext _context;
        private readonly IBannedTokensService _bannedTokensService;
        private readonly IConfiguration _configuration;
        private readonly string RegexPhone = @"^\+7\d{10}$";
        private readonly string RegexBirthDate = @"^\d{2}\.\d{2}\.\d{4}.+";
        private readonly string RegexEmail = @"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$";


        public UserService(AppDbContext context, IBannedTokensService bannedTokensService,IConfiguration configuration)
        {
            _context = context;
            _bannedTokensService = bannedTokensService;
            _configuration = configuration;
        }

        public async Task<TokenResponse> RegisterAsync(UserRegisterModel userRegisterModel)
        {
                var existingUser = _context.Users.SingleOrDefault(user => user.Email == userRegisterModel.Email);
                if (existingUser != null)
                {
                throw new ArgumentException("User with this Email has already exist");
                }
                if(!Regex.IsMatch(userRegisterModel.BirthDate.ToString(),RegexBirthDate) || !Regex.IsMatch(userRegisterModel.PhoneNumber,RegexPhone) || !Regex.IsMatch(userRegisterModel.Email,RegexEmail))
                {
                    throw new ArgumentException("Bad PhoneNumber or BirthDate or email");
                }
                Guid ID = Guid.NewGuid();
                var hashedPassword = HashPassword(userRegisterModel.Password);
                var newUser = new User
                {
                    FullName = userRegisterModel.FullName,
                    Password = hashedPassword,
                    Email = userRegisterModel.Email,
                    Gender = userRegisterModel.Gender,
                    PhoneNumber = userRegisterModel.PhoneNumber,
                    Id = ID,
                    AddressId = userRegisterModel.Address,
                };
                _context.Users.Add(newUser);
                _context.SaveChanges();
                TokenResponse token = GenerateToken(newUser);
                return token;
        }

        public async Task<TokenResponse> LoginAsync(LoginCredentials LC)
        {

                var user = _context.Users.SingleOrDefault(u => u.Email == LC.Email);
                var HashUserPassword = HashPassword(LC.Password);
            if (!Regex.IsMatch(LC.Email, RegexEmail))
            {
                throw new ArgumentException("Bad Email");
            }
                if (user == null || HashUserPassword != user.Password)
                {
                    return null;
                }
                TokenResponse token = GenerateToken(user);
                return token;
        }

        public async Task<UserDto> GetProfileAsync(Guid userId)
        {
            /*
            var token = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
            if (_bannedTokensService.IsTokenBanned(token))
            {
                return Unauthorized("401 Unauthorized");
            }
            */
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            if (user == null)
            {
                //return NotFound("User not found");
                return null;
            }
            UserDto userDto = new UserDto
            {
                Address = user.AddressId,
                Email = user.Email,
                BirthDate = user.BirthDate,
                FullName = user.FullName,
                Gender = user.Gender,
                Id = user.Id,
                PhoneNumber = user.PhoneNumber
            };
            return userDto;
        }

        public async Task<TokenResponse> EditProfileAsync(Guid userId, UserEditModel userEditModel)
        {
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            if (user == null)
            {
                //return NotFound("User not found");
                return null;
            }
            if (!Regex.IsMatch(userEditModel.BirthDate.ToString(), RegexBirthDate) || !Regex.IsMatch(userEditModel.PhoneNumber, RegexPhone))
            {
                throw new ArgumentException();
            }
            user.BirthDate = userEditModel.BirthDate;
            user.AddressId = userEditModel.Address;
            user.FullName = userEditModel.FullName;
            user.Gender = userEditModel.Gender;
            user.PhoneNumber = userEditModel.PhoneNumber;
            _context.SaveChanges();
            TokenResponse tokenNew = GenerateToken(user);
            return tokenNew;
        }

        public async Task  LogOutAsync(TokenBan token)
        {
                _context.TokensBan.Add(token);
                _context.SaveChanges();
        }
        /*
        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }
        */

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
        private TokenResponse GenerateToken(User user)
        {
            var claims = new List<Claim> {new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.MobilePhone, user.PhoneNumber),
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Gender, user.Gender.ToString()),
                    new Claim(ClaimTypes.StreetAddress, user.AddressId.ToString()),
                    new Claim(ClaimTypes.Hash,user.Password)};
            // создаем JWT-токен
            var jwt = new JwtSecurityToken(
                    issuer: _configuration["Token:ISSUER"],
                    audience: _configuration["Token:AUDIENCE"],
                    claims: claims,
            expires: DateTime.UtcNow.Add(TimeSpan.FromHours(1)),
                    signingCredentials: new SigningCredentials(new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Token:KEY"])), SecurityAlgorithms.HmacSha256));
            return new TokenResponse { token = new JwtSecurityTokenHandler().WriteToken(jwt) };
        }
        /*
        public bool IsBanned(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if(banToken == null)
            {
                return false;
            }
            return true;
        }
        */
    }
}
