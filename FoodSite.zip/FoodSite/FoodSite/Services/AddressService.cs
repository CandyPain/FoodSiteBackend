﻿using FoodSite.Data;
using FoodSite.Models;
using FoodSite.Models.enums;
using FoodSite.Models.Others;
using System.Security.Authentication;

namespace FoodSite.Services
{
    public class AddressService : IAddressService
    {
        private readonly AppDbContext _context;

        public AddressService(AppDbContext context)
        {
            _context = context;
        }
        public List<SearchAddressModel> Chain(Guid id)
        {
            IQueryable<Address> query = _context.Addresses.AsQueryable();
            Address currentAddress = query.FirstOrDefault(a => a.objectGuid == id);
            if(currentAddress == null) { throw new ArgumentException(); }
            List<Address> chain = new List<Address>();
            while(currentAddress.objectLevel != GarAddressLevel.Region)
            {
                chain.Add(currentAddress);
                currentAddress = query.FirstOrDefault(c => c.parentLevel == currentAddress.objectId);
            }
            chain.Add(currentAddress);
            List<SearchAddressModel> result = chain.Select(c => new SearchAddressModel
            {
                ObjectGuid = c.objectGuid,
                ObjectId = c.objectId,
                ObjectLevel = (GarAddressLevel)Enum.ToObject(typeof(GarAddressLevel), c.objectLevel),
                Text = c.text,
                ObjectLevelText = c.objectLevel.ToString()
            }).ToList();
            return result;
            //Read();
            //return null;
        }
        public List<SearchAddressModel> Search(int id, string query)
        {
            IQueryable<Address> queryAddress = _context.Addresses.Where(c => c.text.Contains(query) && c.parentLevel == id);
            if(queryAddress == null)
            {
                throw new ArgumentException();
            }
            List<SearchAddressModel> model = queryAddress.Select(result => new SearchAddressModel
            {
                ObjectGuid = result.objectGuid,
                ObjectId = result.objectId,
                ObjectLevel = (Models.enums.GarAddressLevel)result.objectLevel,
                ObjectLevelText = result.objectLevel.ToString(),
                Text = result.text,
            }).ToList();
            return model;
        }
        public void Read()
        {
            List<Address> addresses = new List<Address>();
            string[] lines = File.ReadAllLines("C:\\Users\\Artyom\\Desktop\\Adres.txt");

            foreach (string line in lines)
            {
                //string cleanLine = line.Replace("\"", "");
                string[] parts = line.Split(',');

                Address address = new Address
                {
                    objectId = int.Parse(parts[0]),
                    objectGuid = Guid.Parse(parts[1]),
                    text = parts[2],
                    objectLevel = (GarAddressLevel)(int.Parse(parts[3])-1),
                    parentLevel = int.Parse(parts[4])
                };

                addresses.Add(address);
            }
            _context.Addresses.AddRange(addresses);
            _context.SaveChanges();
        }
        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }

    }
}
