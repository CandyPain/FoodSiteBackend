﻿using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using FoodSite.Models.Others;

namespace FoodSite.Services
{
    public interface IDishService
    {
        Task<PageDishListDto> GetDishesAsync(DishCategory?[] categories, bool IsVegetarian, DishSorting Sort, int page);
        Task<DishDto> GetDishAsync(Guid id);
        bool CheckRating(Guid userId, Guid dishId);
        Task SetRatingAsync(Guid userId, Guid dishId, int rating);
    }

}
