﻿using FoodSite.Models;
using FoodSite.Models.Dto;

namespace FoodSite.Services
{
    public interface IBasketService
    {
        Task<List<DishBasketDto>> GetBasketAsync(Guid userId);
        Task AddDishAsync(Guid userId, Guid dishId, int Count);
        Task DeleteDishAsync(Guid userId, Guid dishId, bool decrease);
    }

}
