﻿namespace FoodSite.Services.ModelsForServices
{
    public class BannedToken
    {
        public string Token { get; set; }
    }
}
