﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using FoodSite.Models.Others;
using System.Security.Authentication;
using System.Security.Claims;

namespace FoodSite.Services
{
    public class DishService : IDishService
    {
        private readonly AppDbContext _context;
        private const int PageSize = 5;

        public DishService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<PageDishListDto> GetDishesAsync(DishCategory?[] categories, bool IsVegetarian, DishSorting Sort, int page)
        {
            bool allCategoriesValid = categories.All(c => Enum.IsDefined(typeof(DishCategory), c));
            bool sortIsValid = Enum.IsDefined(typeof(DishSorting), Sort);
            if(!allCategoriesValid || !sortIsValid)
            {
                throw new ArgumentException("Bad Data");
            }
            IQueryable<Dish> query = _context.Dishes;
            //List<Dish> dishes = query.ToList();
                query = query.Where(q => categories.Contains(q.Category));
            if (IsVegetarian == true)
            {
                query = query.Where(q => q.Vegetarian);
            }
            string sort = Sort.ToString();
            switch (sort)
            {
                case "NameAsc":
                    query = query.OrderBy(q => q.Name);
                    break;
                case "PriceAsc":
                    query = query.OrderBy(q => q.Price);
                    break;
                case "RatingAsc":
                    query = query.OrderBy(q => q.Rating);
                    break;
                case "NameDesc":
                    query = query.OrderByDescending(q => q.Name);
                    break;
                case "PriceDesc":
                    query = query.OrderByDescending(q => q.Price);
                    break;
                case "RatingDesc":
                    query = query.OrderByDescending(q => q.Rating);
                    break;
            }
            int skip = (page - 1) * PageSize;
            int Count = query.Count();
            query = query.Skip(skip).Take(PageSize);
            List<DishDto> dishDtos = query.Select(d => new DishDto
            {
                Id = d.Id,
                Name = d.Name,
                Description = d.Description,
                Price = d.Price,
                Image = d.Image,
                Vegetarian = d.Vegetarian,
                Rating = d.Rating,
                Category = d.Category
            }).ToList();
            PageDishListDto pageDishListDto = new PageDishListDto
            {
                DishDtos = dishDtos,
                PageInfo = new Models.Others.PageInfoModel
                {
                    size = dishDtos.Count >= 5 ? 5 : dishDtos.Count,
                    count = (Count%PageSize == 0? Count/PageSize : Count/PageSize+1),
                    current = page
                }
            };
            return pageDishListDto;
        }

        public async Task<DishDto> GetDishAsync(Guid id)
        {
            var Dish = _context.Dishes.SingleOrDefault(d => d.Id == id);
            if(Dish == null)
            {
                throw new NotFoundExeption("Dish does not exist");
            }
            DishDto dishDto = new DishDto
            {
                Category = Dish.Category,
                Description = Dish.Description,
                Id = Dish.Id,
                Image = Dish.Image,
                Name = Dish.Name,
                Price = Dish.Price,
                Rating = Dish.Rating,
                Vegetarian = Dish.Vegetarian,
            };
            return dishDto;
        }

        public bool CheckRating(Guid userId, Guid dishId)
        {
            var dish = _context.Dishes.SingleOrDefault(d => d.Id == dishId);
            if(dish == null)
            {
                throw new NotFoundExeption("Dish does not exist");
            }
            var userOrders = _context.Orders
                .Where(o => o.UserId == userId)
                .ToList();
            var userCartItems = _context.CartItems
                .Where(ci => userOrders.Select(o => o.Id).Contains(ci.OrderId))
                .ToList();
            CartItem? item = userCartItems.FirstOrDefault(ci => ci.DishId == dishId);
            if(item != null) { return true; }
            return false;
        }

        public async Task SetRatingAsync(Guid userId, Guid dishId, int rating)        {
            
            Dish? CurrentDish = _context.Dishes.SingleOrDefault(d => d.Id == dishId);
            if (CurrentDish == null)
            {
                throw new NotFoundExeption("Dish does not exist");
            }
            if (CheckRating(userId,dishId))
            {
                double newRating = (CurrentDish.CountRating * CurrentDish.Rating + rating) / (CurrentDish.CountRating + 1);
                CurrentDish.CountRating += 1;
                CurrentDish.Rating = newRating;
                _context.SaveChanges();
                return;
            }
            else
            {
                throw new UnauthorizedAccessException("Forbidden");
            }
        }
        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }
    }
}
