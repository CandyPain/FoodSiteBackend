﻿using FoodSite.Models;
using FoodSite.Models.Others;

namespace FoodSite.Services
{
    public interface IAddressService
    {
        public List<SearchAddressModel> Chain(Guid id);
        public List<SearchAddressModel> Search(int parrentId, string query);
        public void Read();
    }
}
