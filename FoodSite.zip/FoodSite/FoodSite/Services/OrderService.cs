﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using System.Security.Authentication;
using System.Security.Claims;

namespace FoodSite.Services
{
    public class OrderService : IOrderService
    {
        private readonly AppDbContext _context;

        public OrderService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<OrderInfoDto>> GetOrdersAsync(Guid userId)
        {
            IQueryable<Order> query = _context.Orders.Where(o => o.UserId == userId);
            if(query == null)
            {
                throw new NotFoundExeption("Orders not found");
            }
            List<OrderInfoDto> Odreds = query.Select(q => new OrderInfoDto
            {
                DeliveredTime = q.DeliveryTime,
                Id = q.Id,
                OrderTime = q.OrderTime,
                Price = q.Price,
                Status = q.Status,
            }).ToList();
            return(Odreds);
        }

        public async Task<OrderDto> GetOrderAsync(Guid Id, Guid userId)
        {
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            /*
            IQueryable<Order> query = _context.Orders.Where(o => o.Id == Id);
            List<Order> userOrders = _context.Orders.Where(o => o.UserId == user.Id).ToList();
            */
            Order? currentOrder = _context.Orders.SingleOrDefault(o => o.Id == Id);
            if (currentOrder == null)
            {
                throw new NotFoundExeption("Order not found");
            }
            IQueryable<CartItem> query_Cart = _context.CartItems.Where(ci => ci.OrderId == Id);
            List<DishBasketDto> DishBasketDTOS = query_Cart.Select(q => new DishBasketDto
            {
                Id = q.Id,
                Amount = q.Count,
                Name = q.Dish.Name,
                Image = q.Dish.Image,
                Price = q.Dish.Price,
                TotalPrice = q.Dish.Price * q.Count,
            }).ToList();

            var orderDto = new OrderDto
            {
                Id = currentOrder.Id,
                DeliveredTime = currentOrder.DeliveryTime,
                OrderTime = currentOrder.OrderTime,
                Status = currentOrder.Status,
                Price = currentOrder.Price,
                AddressId = currentOrder.AddressId,
                dishes = DishBasketDTOS
            };

            return orderDto;
        }

        public async Task<OrderCreateDto> CreateOrderAsync(Guid userId)
        {
            var user = _context.Users.SingleOrDefault(user => user.Id == userId);
            List<Order> userOrders = _context.Orders.Where(o => o.UserId == user.Id).ToList();
            Order? CurrentOrder = userOrders.FirstOrDefault(o => o.Status == OrderStatus.CurrentOrder);
            if (CurrentOrder == null)
            {
                throw new NotFoundExeption("Order not found");
            }
            CurrentOrder.OrderTime = DateTime.Now;
            CurrentOrder.DeliveryTime = DateTime.Now.AddHours(2);
            CurrentOrder.Status = OrderStatus.InProcessing;
            OrderCreateDto orderCreateDto = new OrderCreateDto { AddressId = CurrentOrder.AddressId, DelyveryTime = CurrentOrder.DeliveryTime };
            _context.SaveChanges();
            return orderCreateDto;
        }

        public async Task<OrderStatus> PostOrderStatusAsync(Guid id)
        {
            Order? currentOrder = _context.Orders.SingleOrDefault(o => o.Id == id);
            if (currentOrder == null)
            {
                throw new NotFoundExeption("Order not found");
            }
            currentOrder.Status = OrderStatus.Delivered;
            _context.SaveChanges();
            return currentOrder.Status;
        }
        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }
    }
}
