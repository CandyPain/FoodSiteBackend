﻿using FoodSite.Data;
using FoodSite.Models;
using FoodSite.Services.ModelsForServices;
using Microsoft.EntityFrameworkCore;
using System.Security.Authentication;

namespace FoodSite.Services
{
    public class BannedTokensService: IBannedTokensService
    {
        private readonly AppDbContext _context;
        public BannedTokensService(AppDbContext context)
        {
            _context = context;
        }

        public void CheckAuthentication(TokenBan token)
        {
            var banToken = _context.TokensBan.FirstOrDefault(t => t.BannedToken == token.BannedToken);
            if (banToken != null)
            {
                throw new AuthenticationException();
            }
        }
    }
}
