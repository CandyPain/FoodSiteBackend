﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using FoodSite.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using Microsoft.Extensions.ObjectPool;
using Microsoft.IdentityModel.Tokens;
using System.Security.Authentication;
using System.Security.Claims;
using static FoodSite.Models.enums.DishCategory;

namespace FoodSite.Controllers
{
    [ApiController]
    [Route("api/dish")]
    public class DishController : ControllerBase
    {
        private readonly AppDbContext _context;
        private readonly int PageSize = 5;
        private readonly IBannedTokensService _banTokensService;

        private readonly IDishService _dishService;

        public DishController(IDishService dishService, IBannedTokensService banTokensService)
        {
            _dishService = dishService;
            _banTokensService = banTokensService;
        }

        [HttpGet]
        public async Task<IActionResult> GetDishes([FromQuery]DishCategory?[] categories,bool IsVegeterian = false,DishSorting Sort = DishSorting.PriceAsc, int page = 1)
        {
            try
            {
                PageDishListDto pageDishListDto = await _dishService.GetDishesAsync(categories, IsVegeterian, Sort, page);
                return Ok(pageDishListDto);
            }
            catch (ArgumentException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }

        [Route("{id}")]
        [HttpGet]
        public async Task<IActionResult> GetDish(Guid id) 
        {
            try
            {
                DishDto dishDto =await _dishService.GetDishAsync(id);
                return Ok(dishDto);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("{id}/rating/check")]
        [HttpGet]
        [Authorize]
        public IActionResult CheckRating(Guid id)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                bool result = _dishService.CheckRating(userId, id);
                return Ok(result);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("{id}/rating")]
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> SetRating(Guid id, int rating) 
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _dishService.SetRatingAsync(userId, id, rating);
                return Ok();
            }
            catch(UnauthorizedAccessException ex)
            {
                return StatusCode(403, ex.Message);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
    }
}
