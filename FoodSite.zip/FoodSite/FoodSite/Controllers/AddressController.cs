﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Services;
using Microsoft.AspNetCore.Mvc;
using System.Security.Authentication;

namespace FoodSite.Controllers
{
    [ApiController]
    [Route("api/address")]
    public class AddressController : ControllerBase
    {
        private readonly IAddressService _addressService;
        public AddressController(IAddressService addressService)
        {
            _addressService = addressService;
        }
        [HttpGet("chain")]
        public IActionResult chain(Guid id)
        {
            try
            {
                var result = _addressService.Chain(id);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return StatusCode(400, "Bad Data");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [HttpGet("search")]
        public IActionResult search(int id, string query)
        {
            try
            {
                var result = _addressService.Search(id, query);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return StatusCode(400, "Bad Data");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }

    }
}
