﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using FoodSite.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Authentication;
using System.Security.Claims;

namespace FoodSite.Controllers
{
    [ApiController]
    [Route("api/order")]
    public class OrderController : ControllerBase
    {
        private readonly IOrderService _orderService;
        private readonly IBannedTokensService _banTokensService;

        public OrderController(IOrderService orderService, IBannedTokensService banTokensService)
        {
            _orderService = orderService;
            _banTokensService = banTokensService;
        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetOrders() 
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var Orders = await _orderService.GetOrdersAsync(userId);
                return Ok(Orders);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }

        }
        [Route("{id}")]
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetOrder(Guid id)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                var userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var orderDto = await _orderService.GetOrderAsync(id, userId);
                return Ok(orderDto);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }

        [HttpPost]
        [Authorize]
        public async Task<IActionResult> CreateOrder()
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var orderCreateDto = await _orderService.CreateOrderAsync(userId);
                return Ok(orderCreateDto);
            }
             catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("{id}/status")]
        [HttpPost]
        [Authorize]
        public async Task<IActionResult> PostOrderStatus(Guid id)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var status = await _orderService.PostOrderStatusAsync(id);
                return Ok(status);
            }
            catch (NotFoundExeption ex)
            {
                return StatusCode(404, ex.Message);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }

        }
    }
}
