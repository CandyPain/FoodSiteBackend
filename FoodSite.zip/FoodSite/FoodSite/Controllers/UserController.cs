﻿using FoodSite.Data;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.Others;
using FoodSite.Services;
using FoodSite.Services.ModelsForServices;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Reflection;
using System.Security.Authentication;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace FoodSite.Controllers
{
    [ApiController]
    [Route("api/account")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        private readonly IBannedTokensService _banTokensService;

        public UserController(IUserService userService, IBannedTokensService banTokensService)
        {
            _userService = userService;
            _banTokensService = banTokensService;
        }
        [Route("register")]
        [HttpPost]
        [AllowAnonymous]
        public async Task<IActionResult> Register([FromBody] UserRegisterModel userRegisterModel)
        {
            try
            {
                var result = await _userService.RegisterAsync(userRegisterModel);
                return Ok(result);
            }
            catch (ArgumentException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }
        [Route("login")]
        [HttpPost]
        public async Task<IActionResult> Login([FromQuery] LoginCredentials LC)
        {
            try
            {
                var result = await _userService.LoginAsync(LC);
                if(result == null)
                {
                    return BadRequest("Wrong login or password");
                }
                return Ok(result);
            }
            catch(ArgumentException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal server error");
            }
        }

        [Route("profile")]
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetProfile()
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var result = await _userService.GetProfileAsync(userId);
                return Ok(result);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("profile")]
        [HttpPut]
        [Authorize]
        public async Task<IActionResult> EditProfile([FromBody] UserEditModel userEditModel)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                var result = await _userService.EditProfileAsync(userId, userEditModel);
                return Ok(result);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("logout")]
        [HttpPost]
        [Authorize]

        public async Task<IActionResult> LogOut()
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                await _userService.LogOutAsync(token);
                return Ok("LogOut successfully");
            }
            catch(AuthenticationException ex) 
            {
                return StatusCode(401, "Autorization Error");
            }
            catch(ArgumentException ex)
            {
                return StatusCode(400, ex.Message);
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }

        /*
        public bool IsUnauthorized(TokenResponse token)
        {
            var BanToken = 
        }
        /*
        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                byte[] hashedBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                return BitConverter.ToString(hashedBytes).Replace("-", "").ToLower();
            }
        }
        private TokenResponse GenerateToken(User user)
        {
            var claims = new List<Claim> {new Claim(ClaimTypes.Email, user.Email),
                    new Claim(ClaimTypes.MobilePhone, user.PhoneNumber),
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Gender, user.Gender.ToString()),
                    new Claim(ClaimTypes.StreetAddress, user.AddressId.ToString()),
                    new Claim(ClaimTypes.Hash,user.Password)};
            // создаем JWT-токен
            var jwt = new JwtSecurityToken(
                    issuer: AuthOptions.ISSUER,
                    audience: AuthOptions.AUDIENCE,
                    claims: claims,
                    expires: DateTime.UtcNow.Add(TimeSpan.FromHours(1)),
                    signingCredentials: new SigningCredentials(AuthOptions.GetSymmetricSecurityKey(), SecurityAlgorithms.HmacSha256));
            return new TokenResponse {token = new JwtSecurityTokenHandler().WriteToken(jwt) };
        }
        */
    }
}
