﻿using FoodSite.Data;
using FoodSite.Exeptions;
using FoodSite.Models;
using FoodSite.Models.Dto;
using FoodSite.Models.enums;
using FoodSite.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Security.Authentication;
using System.Security.Claims;

namespace FoodSite.Controllers
{
    [ApiController]
    [Route("api/basket")]
    public class BasketController : ControllerBase
    {
        private readonly IBasketService _basketService;
        private readonly IBannedTokensService _banTokensService;

        public BasketController(IBasketService basketService, IBannedTokensService banTokensService)
        {
            _basketService = basketService;
            _banTokensService = banTokensService;
        }
        [HttpGet]
        [Authorize]
        public async Task<IActionResult> GetBasket() 
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                List<DishBasketDto> basket =await _basketService.GetBasketAsync(userId);
                return Ok(basket);
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
        [Route("dish/{dishId}")] 
        [HttpPost()]
        [Authorize]
        public async Task<IActionResult> AddDish(Guid dishId, int Count)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _basketService.AddDishAsync(userId, dishId, Count);
                return Ok("Успешно добавленно");
            }
            catch(NotFoundExeption ex)
            {
                return StatusCode(404, "Resource Not Found");
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }

        [Route("dish/{dishId}")]
        [HttpDelete()]
        [Authorize]
        public async Task<IActionResult> DeleteDish(Guid dishId, bool Decrease)
        {
            try
            {
                TokenBan token = new TokenBan { BannedToken = HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "") };
                _banTokensService.CheckAuthentication(token);
                Guid userId = Guid.Parse(User.FindFirstValue(ClaimTypes.NameIdentifier));
                await _basketService.DeleteDishAsync(userId, dishId, Decrease);
                return Ok("Удалено");
            }
            catch(NotFoundExeption ex)
            {
                return StatusCode(404, "Resource Not Found");
            }
            catch (AuthenticationException ex)
            {
                return StatusCode(401, "Autorization Error");
            }
            catch (Exception ex) { return StatusCode(500, "Internal server error"); }
        }
    }
}
