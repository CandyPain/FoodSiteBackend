﻿using FoodSite.Models.enums;

namespace FoodSite.Models
{
    public class Address
    {
        public Guid objectGuid { get; set; }
        public int objectId { get; set; }
        public string text { get; set; }
        public GarAddressLevel objectLevel { get; set; }
        public int parentLevel { get; set; }
    }
}
