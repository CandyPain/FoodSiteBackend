﻿using System.Text.Json.Serialization;

namespace FoodSite.Models.enums
{
    [JsonConverter(typeof(JsonStringEnumConverter))]
    public enum OrderStatus
    {
        InProcessing = 0,
        CurrentOrder = 1,
        Delivered = 2,
    }
}
