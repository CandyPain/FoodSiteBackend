﻿using System.Text.Json.Serialization;

namespace FoodSite.Models.enums
{
        [JsonConverter(typeof(JsonStringEnumConverter))]
        public enum DishSorting
        {
            NameAsc = 0,
            NameDesc = 1,
            PriceAsc = 2,
            PriceDesc = 3,
            RatingAsc = 4,
            RatingDesc = 5,
        }
}
