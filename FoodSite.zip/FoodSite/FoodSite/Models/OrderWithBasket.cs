﻿namespace FoodSite.Models
{
    public class OrderWithBasket
    {
        public Order Order { get; set; }
        public List<CartItem> CartItems { get; set; }
        public OrderWithBasket(Order order, List<CartItem> cartItems)
        {
            this.Order = order;
            this.CartItems = cartItems;
        }
    }
}
