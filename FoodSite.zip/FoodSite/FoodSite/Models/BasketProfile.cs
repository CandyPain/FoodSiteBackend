﻿namespace FoodSite.Models
{
    public class BasketProfile
    {
        public int Count { get; set; }
        public Guid DishId { get; set; }
        public Guid OrderId { get; set; }
    }
}
