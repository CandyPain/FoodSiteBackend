﻿namespace FoodSite.Models.Others
{
    public class LoginCredentials
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
