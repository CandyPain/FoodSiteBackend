﻿namespace FoodSite.Models.Others
{
    public class PageInfoModel
    {
        public int size { get; set; }
        public int count { get; set; }
        public int current { get; set; }
    }
}
