﻿namespace FoodSite.Models.Others
{
    public class TokenResponse
    {
        public string token { get; set; }
    }
}
