﻿namespace FoodSite.Models
{
    public class CartItem
    {
        public Guid Id { get; set; }
        public int Count { get; set; }
        public Guid DishId { get; set; }
        public Dish Dish { get; set; }
        public Guid OrderId { get; set; }
        public Order Order { get; set; }
        public CartItem(Guid DishId,Guid OrderId, int count)
        {
            Id = Guid.NewGuid();
            this.DishId = DishId;
            this.OrderId = OrderId;
            this.Count = count;
        }
    }
}
