﻿namespace FoodSite.Models.Dto
{
    public class OrderCreateDto
    {
        public DateTime DelyveryTime { get; set; }
        public Guid AddressId {  get; set; }
    }
}
