﻿using FoodSite.Models.enums;

namespace FoodSite.Models.Dto
{
    public class OrderDto
    {
        public Guid Id { get; set; }
        public DateTime DeliveredTime { get; set; }
        public DateTime OrderTime   { get; set; }
        public OrderStatus Status { get; set; }
        public decimal Price { get; set; }
        public Guid AddressId { get; set; }
        public List<DishBasketDto> dishes { get; set; }
    }
}
