﻿using FoodSite.Models.enums;
using FoodSite.Models.Others;
using System.Runtime.Serialization;

namespace FoodSite.Models.Dto
{
    public class PageDishListDto
    {
        public List<DishDto> DishDtos { get; set; }
        public PageInfoModel PageInfo { get; set; }
    }
}
