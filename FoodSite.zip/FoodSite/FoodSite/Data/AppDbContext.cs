﻿using FoodSite.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodSite.Data
{
    public class AppDbContext:DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<User> Users { get; set; }
        public DbSet<Dish> Dishes { get; set; }
        public DbSet<CartItem> CartItems { get; set; }
        public DbSet<Order> Orders { get; set; }

        public DbSet<Address> Addresses { get; set; } 
        public DbSet<TokenBan> TokensBan { get; set; }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            modelBuilder.Entity<CartItem>()
                .HasKey(ci => ci.Id );

            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.Dish)
                .WithMany()
                .HasForeignKey(ci => ci.DishId);

            modelBuilder.Entity<CartItem>()
                .HasOne(ci => ci.Order)
                .WithMany()
                .HasForeignKey(ci => ci.OrderId);

            modelBuilder.Entity<Order>()
            .HasOne(o => o.User)
            .WithMany()
            .HasForeignKey(o => o.UserId)
            .OnDelete(DeleteBehavior.ClientSetNull);

            modelBuilder.Entity<Address>()
                .HasKey(a => a.objectGuid);

        }
    }
}
