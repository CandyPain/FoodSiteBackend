﻿using FoodSite.Models;
using Microsoft.EntityFrameworkCore;

namespace FoodSite.Data
{
    /*
    public class AddressContext:DbContext
    {
        public AddressContext(DbContextOptions<AddressContext> options) : base(options) { }
        public DbSet<Address> Addresses;
        
    }
    */
}
