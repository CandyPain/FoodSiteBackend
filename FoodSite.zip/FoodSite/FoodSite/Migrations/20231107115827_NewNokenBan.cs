﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace FoodSite.Migrations
{
    /// <inheritdoc />
    public partial class NewNokenBan : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TokensBan",
                table: "TokensBan");

            migrationBuilder.AlterColumn<string>(
                name: "BannedToken",
                table: "TokensBan",
                type: "nvarchar(1000)",
                maxLength: 1000,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(3000)",
                oldMaxLength: 3000);

            migrationBuilder.AddColumn<int>(
                name: "Id",
                table: "TokensBan",
                type: "int",
                nullable: false,
                defaultValue: 0)
                .Annotation("SqlServer:Identity", "1, 1");

            migrationBuilder.AddPrimaryKey(
                name: "PK_TokensBan",
                table: "TokensBan",
                column: "Id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_TokensBan",
                table: "TokensBan");

            migrationBuilder.DropColumn(
                name: "Id",
                table: "TokensBan");

            migrationBuilder.AlterColumn<string>(
                name: "BannedToken",
                table: "TokensBan",
                type: "nvarchar(3000)",
                maxLength: 3000,
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(1000)",
                oldMaxLength: 1000);

            migrationBuilder.AddPrimaryKey(
                name: "PK_TokensBan",
                table: "TokensBan",
                column: "BannedToken");
        }
    }
}
